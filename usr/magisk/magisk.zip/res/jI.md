# alpha更新日志

重大行为变化：magiskd内部挂载点于不再使用后卸载。

新功能：强化的安全模式。如果连续两次不能正常开机，第三次Magisk会自动进入安全模式。
安全模式下关闭全部功能，禁用全部模块，仅Magisk应用可以使用su。
电脑调试请使用`adb shell 'PATH=$PATH:/debug_ramdisk su'`。

## Magisk (4d5510be-alpha)
- [App] 还原boot镜像后删除备份文件
- [General] 不自动解锁设备块
- [App] 不主动请求权限
- [General] 保留ROOTOVL临时文件
- [App] 通过appcenter检查和下载更新
- [App] 添加遥测 https://t.me/s/magiskalpha/473
- [General] 使阻止列表在zygisk未启用时可以工作
- [General] 移除addon.d支持
- [General] 取消/system/etc/hosts可写的例外,请修改/data/adb/modules/hosts/system/etc/hosts
- [MagiskSU] 支持移除权能
- [General] 支持用户限制Root权能 [使用旧版libsu的应用会错误识别为无root]
- [General] 初始安装后自动复制文件
- [App] 添加备用DoH
- [MagiskInit] 避免对2SI设备修补init文件
- [General] 删除镜像，原子挂载不再需要它
- [General] magisk tmpfs路径固定后，魔法挂载不再是必须的，让它可选
- [General] 增强安全模式
- [App] 重启菜单可以设置下次开机进入Magisk安全模式
- [Denylist] 增强uid跟踪，自动从阻止列表删除已经卸载的应用。提升app启动性能，zygisk不再扫描应用列表。
- [General] 提升app启动性能，zygisk不再在每个app启动时检查重打包magisk app的签名。
- [MagiskPolicy] 修复adb无法连接lldb服务端
- [MagiskPolicy] 大幅减少规则数量
- [MagiskPolicy] 修复部分设备无法连接WiFi
- [General] 绕过部分自定义ROM的内核会隐藏su文件的问题
- [General] 绕过部分内核不会广播挂载对等组事件的问题

# 上游更新日志

## 2024.2.3 Magisk v27.0

- [Zygisk] Introduce new code injection mechanism
- [Zygisk] Support new signature introduced in U QPR2
- [SEPolicy] Update libsepol to properly set some policy config bits
- [MagiskBoot] Support compressing `init` so Magisk is installable on devices with small boot partitions
- [ResetProp] Add new wait for property feature `resetprop -w`

### Full Changelog: [here](https://topjohnwu.github.io/Magisk/changes.html)
